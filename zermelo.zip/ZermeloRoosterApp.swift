import SwiftUI

@main
struct ZermeloRoosterApp: App {
    @StateObject private var authService = ZermeloAuthService()

    var body: some Scene {
        WindowGroup {
            Group {
                if authService.isLoggedIn {
                    // Hier komt in de volgende fase het echte roosterscherm.
                    VStack(spacing: 12) {
                        Text("Ingelogd bij \(authService.schoolName ?? "")")
                            .font(.headline)
                        Text("Hier komt straks het rooster.")
                            .foregroundColor(.secondary)
                        Button("Uitloggen") {
                            authService.logout()
                        }
                        .padding(.top, 20)
                    }
                } else {
                    LoginView()
                }
            }
            .environmentObject(authService)
        }
    }
}
