import Foundation

enum ZermeloAuthError: LocalizedError {
    case invalidSchoolName
    case serverError
    case decodingFailed

    var errorDescription: String? {
        switch self {
        case .invalidSchoolName: return "Ongeldige schoolnaam."
        case .serverError: return "Zermelo gaf een foutmelding terug. Controleer je code."
        case .decodingFailed: return "Het antwoord van Zermelo kon niet worden verwerkt."
        }
    }
}

/// Het JSON-antwoord van POST /api/oauth/token?code=...
struct ZermeloTokenResponse: Decodable {
    let access_token: String
    let token_type: String
    let expires_in: Int
}

/// Houdt de inlogstatus bij en regelt het wisselen van een eenmalige
/// Zermelo-code naar een access token, dat veilig in de Keychain belandt.
@MainActor
final class ZermeloAuthService: ObservableObject {

    @Published private(set) var isLoggedIn: Bool
    @Published private(set) var schoolName: String?

    private let tokenKey = "zermelo_access_token"
    private let schoolDefaultsKey = "zermelo_school"

    init() {
        let storedSchool = UserDefaults.standard.string(forKey: schoolDefaultsKey)
        self.schoolName = storedSchool
        self.isLoggedIn = KeychainHelper.read(for: tokenKey) != nil
    }

    var accessToken: String? {
        KeychainHelper.read(for: tokenKey)
    }

    /// De URL waar de gebruiker inlogt en zijn koppelcode genereert.
    func loginURL(forSchool school: String) -> URL? {
        let trimmed = school.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !trimmed.isEmpty else { return nil }
        return URL(string: "https://\(trimmed).zportal.nl")
    }

    /// Wisselt de eenmalige code uit Zermelo in voor een access token.
    func exchangeCode(_ code: String, school: String) async throws {
        let trimmedSchool = school.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let trimmedCode = code.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !trimmedSchool.isEmpty,
              let url = URL(string: "https://\(trimmedSchool).zportal.nl/api/oauth/token?code=\(trimmedCode)") else {
            throw ZermeloAuthError.invalidSchoolName
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw ZermeloAuthError.serverError
        }

        guard let tokenResponse = try? JSONDecoder().decode(ZermeloTokenResponse.self, from: data) else {
            throw ZermeloAuthError.decodingFailed
        }

        KeychainHelper.save(tokenResponse.access_token, for: tokenKey)
        UserDefaults.standard.set(trimmedSchool, forKey: schoolDefaultsKey)

        self.schoolName = trimmedSchool
        self.isLoggedIn = true
    }

    func logout() {
        KeychainHelper.delete(for: tokenKey)
        UserDefaults.standard.removeObject(forKey: schoolDefaultsKey)
        self.schoolName = nil
        self.isLoggedIn = false
    }
}
