import SwiftUI
import SafariServices

struct LoginView: View {
    @EnvironmentObject var authService: ZermeloAuthService

    @State private var schoolName: String = ""
    @State private var code: String = ""
    @State private var showSafari = false
    @State private var errorMessage: String?
    @State private var isLoading = false

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Koppel je Zermelo-account")
                        .font(.title2.bold())

                    Text("Vul de naam van je school in zoals die in je Zermelo-link staat. Bijvoorbeeld 'nassau' als jouw school inlogt via nassau.zportal.nl.")
                        .font(.subheadline)
                        .foregroundColor(.secondary)

                    TextField("Schoolnaam, bv. nassau", text: $schoolName)
                        .textFieldStyle(.roundedBorder)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)

                    Button("Open Zermelo om een code te genereren") {
                        showSafari = true
                    }
                    .disabled(schoolName.trimmingCharacters(in: .whitespaces).isEmpty)

                    Text("Log in, ga naar 'Koppelingen' en kies 'Koppel externe applicatie'. Kopieer de code die verschijnt en plak die hieronder.")
                        .font(.subheadline)
                        .foregroundColor(.secondary)

                    TextField("Plak hier je code", text: $code)
                        .textFieldStyle(.roundedBorder)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)

                    if let errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.footnote)
                    }

                    Button {
                        Task { await submitCode() }
                    } label: {
                        HStack {
                            if isLoading {
                                ProgressView()
                            }
                            Text(isLoading ? "Bezig..." : "Inloggen")
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(schoolName.trimmingCharacters(in: .whitespaces).isEmpty || code.trimmingCharacters(in: .whitespaces).isEmpty || isLoading)
                }
                .padding()
            }
            .navigationTitle("Inloggen")
        }
        .sheet(isPresented: $showSafari) {
            if let url = authService.loginURL(forSchool: schoolName) {
                SafariView(url: url)
            }
        }
    }

    private func submitCode() async {
        errorMessage = nil
        isLoading = true
        defer { isLoading = false }

        do {
            try await authService.exchangeCode(code, school: schoolName)
        } catch {
            errorMessage = "Inloggen mislukt. Controleer je schoolnaam en code, en probeer het opnieuw. Let op: de code werkt maar één keer."
        }
    }
}

/// Wrapper om SFSafariViewController bruikbaar te maken in SwiftUI.
struct SafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        SFSafariViewController(url: url)
    }

    func updateUIViewController(_ uiViewController: SFSafariViewController, context: Context) {}
}
