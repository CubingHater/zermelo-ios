# Zermelo Rooster App — Fase 1: inloggen

## Wat dit is
Vier Swift-bestanden die samen de Zermelo-koppeling regelen: de gebruiker
vult zijn schoolnaam in, logt in via Zermelo, genereert daar een eenmalige
code via 'Koppelingen' > 'Koppel externe applicatie', en plakt die code in
de app. De app wisselt die code in voor een persoonlijk access token en
slaat dat veilig op in de Keychain.

## Zo zet je dit in Xcode (versie die op Big Sur draait)
1. Open Xcode, kies File > New > Project > App.
2. Interface: SwiftUI. Language: Swift. Zet "Include Tests" uit voor nu.
3. Verwijder het automatisch aangemaakte `ContentView.swift` en het
   bestand met `@main` dat Xcode zelf aanmaakt (anders heb je twee
   `@main`-entrypoints).
4. Sleep de vier bestanden (`KeychainHelper.swift`, `ZermeloAuthService.swift`,
   `LoginView.swift`, `ZermeloRoosterApp.swift`) in je projectnavigator.
   Zorg dat "Copy items if needed" aanstaat en je target aangevinkt is.
5. Build target (▶) en kies je eigen iPhone als doel, niet de simulator,
   want SFSafariViewController en de Zermelo-login werken het prettigst
   op een echt toestel.
6. Op je iPhone: ga naar Instellingen > Algemeen > VPN en apparaatbeheer
   en vertrouw je eigen Apple ID/certificaat de eerste keer dat je de app
   start vanaf Xcode.

## Testen
Vul bij "Schoolnaam" het stukje in dat in jullie Zermelo-link staat vóór
`.zportal.nl` (bijvoorbeeld bij `nassau.zportal.nl` vul je `nassau` in).
Log in, ga naar Koppelingen, kies "Koppel externe applicatie", kopieer de
code en plak die in de app. Bij succes zie je het tijdelijke scherm
"Ingelogd bij ...".

## Over delen met klasgenoten
TestFlight kan niet zonder Xcode 26 (en dus zonder macOS-update), maar dat
is niet nodig: AltStore sideloadt apps buiten App Store Connect om, dus
dat werkt prima met je huidige Xcode-versie. Daar gaan we naar kijken
zodra de app verder gevorderd is.

## Volgende stap
Fase 2: het rooster zelf ophalen en tonen. Daarvoor zoek ik eerst de
exacte endpointnaam en velden op in de Zermelo-documentatie, zodat we
geen velden gebruiken die niet bestaan, en bouw ik daar een
`ZermeloAPIClient` + roosterscherm op.
